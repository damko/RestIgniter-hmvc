This code is here just to provide autocomplete support in eclipse

Thanks to Johnny Skoumbourdis for his job

http://www.web-and-development.com/codeigniter-and-eclipse-autocomplete